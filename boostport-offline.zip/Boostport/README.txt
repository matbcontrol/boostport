BOOSTPORT, YOUR COPY

1. Double-click Boostport.html. It opens in your browser and works without internet.
2. Pick your Arc boosts folder (on a Mac: ~/Library/Application Support/Arc/boosts;
   in the Mac folder picker press Cmd Shift G and paste that path).
3. Untick anything you want to leave behind, choose colors if asked, download the archive.
4. Install steps are inside the archive in README.txt.

Nothing is uploaded: the page is not allowed to make any network request.
Keep this file; you can use it as often as you like.

Boostport is an independent tool, not affiliated with The Browser Company.
